import os
import feedparser
import re
from telegram_bot import send_telegram_message

RSS_FEED_URL = 'https://rss.app/feeds/kmgkxuRUEPyKOcqk.xml'
POSTED_FILE = 'posted_links.txt'

def clean_html(text):
    allowed_tags = ['b', 'i', 'u', 'a']
    def remove_tags(match):
        tag = match.group(1)
        return match.group(0) if tag.lower() in allowed_tags else ''
    return re.sub(r'</?([^ >]+)[^>]*>', remove_tags, text)

def load_posted_links():
    if not os.path.exists(POSTED_FILE):
        return set()
    with open(POSTED_FILE, 'r') as f:
        return set(line.strip() for line in f.readlines())

def save_posted_link(link):
    with open(POSTED_FILE, 'a') as f:
        f.write(link + '\n')

def check_rss():
    posted_links = load_posted_links()
    feed = feedparser.parse(RSS_FEED_URL)
    already_posted = 0
    new_sent = 0

    for i, entry in enumerate(feed.entries, start=1):
        link = entry.link
        summary = getattr(entry, 'summary', '')

        if link in posted_links:
            already_posted += 1
            continue
        else:
            print(f"[📤] Sending entry #{i}...")

        try:
            cleaned_summary = clean_html(summary)
            message = f"📰 <b>{entry.title}</b>\n\n{cleaned_summary}\n\n🔗 {link}"
            send_telegram_message(message)
            save_posted_link(link)
            new_sent += 1
        except Exception as e:
            print(f"[❌] Error sending entry #{i}: {e}")

    print(f"[✅] Sent: {new_sent} | [↩️] Skipped: {already_posted}")