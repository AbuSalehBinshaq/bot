from keep_alive import keep_alive
from rss_reader import check_rss
import time

SLEEP_SECONDS = 10

if __name__ == '__main__':
    print("🚀 Bot started.")
    keep_alive()  # تشغيل سيرفر Flask
    while True:
        try:
            check_rss()
            time.sleep(SLEEP_SECONDS)
        except Exception as e:
            print(f"[❌] Error in loop: {e}")