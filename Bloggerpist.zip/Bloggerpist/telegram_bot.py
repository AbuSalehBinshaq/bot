import requests
import time

BOT_TOKEN = '8046235347:AAGJ4w8Tmr7w-YpJQIGSgfZFz7R-JQ7sCjU'
ADMIN_CHAT_ID = 6479165880

def send_telegram_message(message):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    data = {
        "chat_id": ADMIN_CHAT_ID,
        "text": message,
        "parse_mode": "HTML",
        "disable_web_page_preview": False
    }
    try:
        response = requests.post(url, json=data)
        if response.status_code == 200:
            print("[✅] Message sent successfully.")
        else:
            print(f"[❌] Telegram Error: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"[❌] Telegram Exception: {e}")
    time.sleep(60)  # تأخير بين الرسائل