import os
import pickle
import time
import random
import feedparser
import requests
from goose3 import Goose
from bs4 import BeautifulSoup
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from flask import Flask
from threading import Thread

# ============ Flask Server ============
app = Flask('')

@app.route('/')
def home():
    return "✅ Bot is running!"

def run():
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    t = Thread(target=run)
    t.start()

# ============ Settings ============
BOT_TOKEN = '8046235347:AAGJ4w8Tmr7w-YpJQIGSgfZFz7R-JQ7sCjU'
ADMIN_CHAT_ID = 6479165880
CHANNEL_USERNAME = '@tarvoztest'
TOKEN_PICKLE = 'token.pkl'
CLIENT_SECRET = 'client_secret.json'
SCOPES = ['https://www.googleapis.com/auth/blogger']
POSTED_LINKS_FILE = 'posted_links.txt'
RSS_FEED_URL = 'https://rss.app/feeds/kmgkxuRUEPyKOcqk.xml'

OPENING_LINES = [
    "📰 Here's the latest from the sports world:",
    "⚽️ Fresh news from Goal:",
    "🔥 Top headline of the day:",
    "📢 New sports update just in:",
    "🏆 Full details about this hot event:"
]

# ============ Telegram ============
def send_telegram_message(chat_id, text, preview=True, button_url=None, button_text="🔘 Open Draft"):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": "HTML",
        "disable_web_page_preview": not preview
    }

    if button_url:
        payload["reply_markup"] = {
            "inline_keyboard": [[
                {"text": button_text, "url": button_url}
            ]]
        }

    try:
        requests.post(url, json=payload)
    except Exception as e:
        print(f"[Telegram Error] {e}")

# ============ Blogger Auth ============
def get_credentials():
    if os.path.exists(TOKEN_PICKLE):
        with open(TOKEN_PICKLE, 'rb') as token:
            return pickle.load(token)

    flow = InstalledAppFlow.from_client_secrets_file(
        CLIENT_SECRET, SCOPES, redirect_uri='urn:ietf:wg:oauth:2.0:oob'
    )
    auth_url, _ = flow.authorization_url(prompt='consent')
    send_telegram_message(ADMIN_CHAT_ID, f"🔑 Open this link to authenticate:\n{auth_url}", preview=False)
    code = input("📥 Paste the code here: ")
    flow.fetch_token(code=code)
    creds = flow.credentials
    with open(TOKEN_PICKLE, 'wb') as token:
        pickle.dump(creds, token)
    return creds

# ============ File Handling ============
def load_posted_links():
    if not os.path.exists(POSTED_LINKS_FILE):
        return set()
    with open(POSTED_LINKS_FILE, 'r') as f:
        return set(line.strip() for line in f.readlines())

def save_posted_link(link):
    with open(POSTED_LINKS_FILE, 'a') as f:
        f.write(link + '\n')

# ============ Article Extraction ============
def extract_image_from_summary(summary_html):
    soup = BeautifulSoup(summary_html, 'html.parser')
    img = soup.find('img')
    if img and img.get('src'):
        return img['src']
    return None

def get_full_article_with_image(url, summary_html):
    try:
        g = Goose()
        article = g.extract(url=url)
        title = article.title
        content_html = f"<h2>{title}</h2>"

        img_url = extract_image_from_summary(summary_html)
        if img_url:
            content_html += f'<img src="{img_url}" alt="Image" style="max-width:100%;height:auto;"><br>'

        opening = random.choice(OPENING_LINES)
        content_html += f"<p>{opening}</p>"
        content_html += "<p>" + article.cleaned_text.replace('\n', '</p><p>') + "</p>"
        return title, content_html
    except Exception as e:
        send_telegram_message(ADMIN_CHAT_ID, f"⚠️ Error extracting article:\n{e}")
        return None, None

# ============ Blogger Post ============
def post_blog(title, content):
    creds = get_credentials()
    service = build('blogger', 'v3', credentials=creds)
    blogs = service.blogs().listByUser(userId='self').execute()
    blog_id = blogs['items'][0]['id']

    body = {
        "kind": "blogger#post",
        "title": title,
        "content": content
    }

    # Save as draft
    post = service.posts().insert(blogId=blog_id, body=body, isDraft=True).execute()
    blog_url = post['url']

    # Send message with button
    send_telegram_message(
        ADMIN_CHAT_ID,
        f"📝 Draft saved:\n<b>{title}</b>",
        button_url=blog_url
    )

    return blog_url

# ============ Main Logic ============
def main():
    send_telegram_message(ADMIN_CHAT_ID, "🚀 The Blogger bot has started successfully!")
    keep_alive()

    posted_links = load_posted_links()
    feed = feedparser.parse(RSS_FEED_URL)

    for entry in feed.entries:
        link = entry.link
        summary = entry.summary

        if link in posted_links:
            print(f"[SKIPPED] {entry.title}")
            continue

        title, content = get_full_article_with_image(link, summary)
        if not content:
            continue

        try:
            post_blog(title, content)
            save_posted_link(link)
        except Exception as e:
            send_telegram_message(ADMIN_CHAT_ID, f"❌ Failed to post:\n{e}")

        print("[WAIT] Sleeping for 3 hours before next post...")
        time.sleep(10800)

# ============ Run ============
if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        send_telegram_message(ADMIN_CHAT_ID, f"🚨 Script crashed:\n{e}")
        raise
    finally:
        send_telegram_message(ADMIN_CHAT_ID, "⚠️ Script stopped or finished.")